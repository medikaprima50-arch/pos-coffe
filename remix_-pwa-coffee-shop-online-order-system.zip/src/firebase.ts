import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Config from firebase-applet-config.json
const firebaseConfig = {
  apiKey: "AIzaSyBELS-7BDE3dlIT19C1xK65w1Vk1dyylhc",
  authDomain: "gen-lang-client-0370773399.firebaseapp.com",
  projectId: "gen-lang-client-0370773399",
  storageBucket: "gen-lang-client-0370773399.firebasestorage.app",
  messagingSenderId: "526170213698",
  appId: "1:526170213698:web:41beb3e3144d691dd98cdb"
};

const databaseId = "ai-studio-22a22863-0b34-4a41-9a3d-102795c3d75f";

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with specific databaseId
export const db = getFirestore(app, databaseId);
