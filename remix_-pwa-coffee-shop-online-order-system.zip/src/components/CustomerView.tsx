import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import {
  collection,
  addDoc,
  query,
  where,
  onSnapshot,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";
import { INITIAL_MENU } from "../data/menu";
import { MenuItem, Order, OrderItem, OrderStatus, LoyaltyAccount, LoyaltyHistory, Voucher } from "../types";
import { REWARD_ITEMS, RewardItem } from "../data/rewards";
import { handleFirestoreError, OperationType } from "../utils/firestore-error";
import {
  Search,
  ShoppingCart,
  Clock,
  Trash2,
  ChevronRight,
  Sparkles,
  ClipboardList,
  Plus,
  Minus,
  CheckCircle2,
  AlertCircle,
  XCircle,
  LogOut,
  Coffee,
  X,
  Gift,
  Coins,
  Award,
  History,
  Tag,
} from "lucide-react";

interface CustomerViewProps {
  onNewNotification: (message: string, type: "success" | "info" | "warning") => void;
}

export default function CustomerView({ onNewNotification }: CustomerViewProps) {
  // Session details stored in localStorage
  const [customerName, setCustomerName] = useState<string>(() => {
    return localStorage.getItem("ks_name") || "";
  });
  const [tableNumber, setTableNumber] = useState<string>(() => {
    return localStorage.getItem("ks_table") || "";
  });
  const [isSessionActive, setIsSessionActive] = useState<boolean>(() => {
    return !!(localStorage.getItem("ks_name") && localStorage.getItem("ks_table"));
  });

  // Mode inputs for session setup
  const [inputName, setInputName] = useState("");
  const [inputTable, setInputTable] = useState("");

  // Store lists & filters
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [myOrders, setMyOrders] = useState<Order[]>([]);

  // Item note modal/input state
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
  const [tempNote, setTempNote] = useState("");

  // Loyalty customer ID, initialized with a steady client-side tracking ID
  const [customerId, setCustomerId] = useState<string>(() => {
    let id = localStorage.getItem("ks_customer_id");
    if (!id) {
      id = `cust_${Math.random().toString(36).substring(2, 10)}`;
      localStorage.setItem("ks_customer_id", id);
    }
    return id;
  });

  // Loyalty variables
  const [loyaltyAccount, setLoyaltyAccount] = useState<LoyaltyAccount | null>(null);
  const [loyaltyHistory, setLoyaltyHistory] = useState<LoyaltyHistory[]>([]);
  const [myVouchers, setMyVouchers] = useState<Voucher[]>([]);
  const [selectedVoucher, setSelectedVoucher] = useState<Voucher | null>(null);

  // Active sub-tab inside Customer Portal: "menu", "history", or "loyalty"
  const [activeTab, setActiveTab] = useState<"menu" | "history" | "loyalty">("menu");

  // Show checkout confirmation dialog
  const [showConfirmCheckout, setShowConfirmCheckout] = useState(false);

  // Show cancellation confirmation list ID
  const [orderIdToCancel, setOrderIdToCancel] = useState<string | null>(null);

  // Show mobile cart drawer
  const [isMobileCartOpen, setIsMobileCartOpen] = useState(false);

  // Fetch or subscribe to real-time order history for this session (table & name)
  useEffect(() => {
    if (!isSessionActive || !customerName || !tableNumber) return;

    // Listen to real-time changes in orders collection for this customer
    const q = query(
      collection(db, "orders"),
      where("customerName", "==", customerName),
      where("tableNumber", "==", tableNumber)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const orderList: Order[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          orderList.push({
            id: docSnap.id,
            ...data,
            // Convert firestore timestamp to standard representation
            createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : (data.createdAt ? new Date(data.createdAt) : new Date()),
            updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : (data.updatedAt ? new Date(data.updatedAt) : new Date()),
          } as Order);
        });

        // Sort dynamically in memory based on createdAt descending
        orderList.sort((a, b) => {
          const aTime = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
          const bTime = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
          return bTime - aTime;
        });

        // Detect real-time updates and trigger client notifications
        if (myOrders.length > 0) {
          orderList.forEach((newOrder) => {
            const oldOrder = myOrders.find((o) => o.id === newOrder.id);
            if (oldOrder && oldOrder.status !== newOrder.status) {
              // Status changed!
              let msg = `Pesanan Anda #${newOrder.id.slice(-4)} `;
              let alertType: "success" | "info" | "warning" = "info";

              switch (newOrder.status) {
                case "accepted":
                  msg += "telah diterima oleh kasir dan tidak bisa dibatalkan.";
                  break;
                case "preparing":
                  msg += "sedang diproses oleh Barista Kopi Senja.";
                  break;
                case "ready":
                  msg += "SIAP DIAMBIL! Silakan kunjungi konter barista kami.";
                  alertType = "success";
                  break;
                case "completed":
                  msg += "telah selesai diproses. Terima kasih!";
                  alertType = "success";
                  break;
                case "cancelled":
                  msg += "telah dibatalkan.";
                  alertType = "warning";
                  break;
              }
              onNewNotification(msg, alertType);
            }
          });
        }

        setMyOrders(orderList);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, "orders");
      }
    );

    return () => unsubscribe();
  }, [isSessionActive, customerName, tableNumber, myOrders.length]);

  // Load and subscribe/listen to Loyalty Account & Logs
  useEffect(() => {
    if (!isSessionActive || !customerId) return;

    const accountRef = doc(db, "loyalty_accounts", customerId);

    // Initializer
    const initAccount = async () => {
      try {
        const snap = await getDoc(accountRef);
        if (!snap.exists()) {
          await setDoc(accountRef, {
            customerId,
            customerName,
            points: 0,
            earnedPointsTotal: 0,
            redeemedPointsTotal: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      } catch (err) {
        console.error("Gagal inisialisasi akun loyalitas:", err);
      }
    };

    initAccount();

    const unsubscribeAccount = onSnapshot(
      accountRef,
      (snap) => {
        if (snap.exists()) {
          setLoyaltyAccount(snap.data() as LoyaltyAccount);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, `loyalty_accounts/${customerId}`);
      }
    );

    // Sync Loyalty History
    const qHistory = query(
      collection(db, "loyalty_history"),
      where("customerId", "==", customerId)
    );
    const unsubscribeHistory = onSnapshot(
      qHistory,
      (snap) => {
        const historyList: LoyaltyHistory[] = [];
        snap.forEach((docSnap) => {
          const data = docSnap.data();
          historyList.push({
            id: docSnap.id,
            ...data,
            createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : (data.createdAt ? new Date(data.createdAt) : new Date())
          } as LoyaltyHistory);
        });
        historyList.sort((a, b) => {
          const aTime = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
          const bTime = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
          return bTime - aTime;
        });
        setLoyaltyHistory(historyList);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, "loyalty_history");
      }
    );

    // Sync Vouchers
    const qVouchers = query(
      collection(db, "vouchers"),
      where("customerId", "==", customerId)
    );
    const unsubscribeVouchers = onSnapshot(
      qVouchers,
      (snap) => {
        const voucherList: Voucher[] = [];
        snap.forEach((docSnap) => {
          const data = docSnap.data();
          voucherList.push({
            id: docSnap.id,
            ...data,
            createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : (data.createdAt ? new Date(data.createdAt) : new Date())
          } as Voucher);
        });
        voucherList.sort((a, b) => {
          const aTime = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
          const bTime = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
          return bTime - aTime;
        });
        setMyVouchers(voucherList);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, "vouchers");
      }
    );

    return () => {
      unsubscribeAccount();
      unsubscribeHistory();
      unsubscribeVouchers();
    };
  }, [isSessionActive, customerId, customerName]);

  // Handle session setup submission
  const handleSetupSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputName.trim() || !inputTable.trim()) {
      alert("Silakan isi nama Anda dan nomor meja Anda!");
      return;
    }
    const cleanName = inputName.trim();
    const cleanTable = inputTable.trim();
    
    localStorage.setItem("ks_name", cleanName);
    localStorage.setItem("ks_table", cleanTable);
    setCustomerName(cleanName);
    setTableNumber(cleanTable);
    setIsSessionActive(true);
    onNewNotification(`Selamat datang ${cleanName}, meja ${cleanTable}! Silakan pesan menu favorit Anda.`, "success");
  };

  const handleClearSession = () => {
    if (confirm("Apakah Anda ingin keluar dari meja ini? Riwayat pesanan tetap tersimpan di server.")) {
      localStorage.removeItem("ks_name");
      localStorage.removeItem("ks_table");
      localStorage.removeItem("ks_customer_id");
      setCustomerName("");
      setTableNumber("");
      setIsSessionActive(false);
      setCart([]);
      setMyOrders([]);
      setLoyaltyAccount(null);
      setLoyaltyHistory([]);
      setMyVouchers([]);
      setSelectedVoucher(null);
    }
  };

  // Cart operations
  const addToCart = (item: MenuItem) => {
    setCart((prevCart) => {
      const existing = prevCart.find((c) => c.id === item.id);
      if (existing) {
        return prevCart.map((c) =>
          c.id === item.id ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [
        ...prevCart,
        {
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: 1,
          notes: "",
        },
      ];
    });
    onNewNotification(`${item.name} dimasukkan ke keranjang.`, "success");
  };

  const removeFromCart = (id: string, name: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
    onNewNotification(`${name} dikeluarkan dari keranjang.`, "warning");
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const nextQty = item.quantity + delta;
            return { ...item, quantity: nextQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const handleSaveNote = (id: string) => {
    setCart((prev) =>
      prev.map((item) => (item.id === id ? { ...item, notes: tempNote } : item))
    );
    setActiveNoteId(null);
    onNewNotification("Catatan pesanan berhasil ditambahkan.", "success");
  };

  const openNoteInput = (id: string, currentNote: string) => {
    setActiveNoteId(id);
    setTempNote(currentNote);
  };

  // Submit/Place order - Trigger confirmation dialog
  const handleCheckout = () => {
    if (cart.length === 0) return;
    setShowConfirmCheckout(true);
  };

  // Helper calculations for voucher discount application
  const isClassicOrSignature = (itemId: string) => {
    const item = INITIAL_MENU.find((m) => m.id === itemId);
    return item && (item.category === "Classic Coffee" || item.category === "Signature Coffee");
  };

  const isSnack = (itemId: string) => {
    const item = INITIAL_MENU.find((m) => m.id === itemId);
    return item && item.category === "Snack & Food";
  };

  const getVoucherDiscountValue = (): number => {
    if (!selectedVoucher) return 0;
    
    switch (selectedVoucher.type) {
      case "discount_10k":
        return Math.min(10000, cartTotal);
      case "discount_25k":
        return Math.min(25000, cartTotal);
      case "free_coffee": {
        const coffeeInCart = cart.filter((item) => isClassicOrSignature(item.id));
        if (coffeeInCart.length === 0) return 0;
        const maxPriceClassic = Math.max(...coffeeInCart.map((item) => item.price));
        return maxPriceClassic;
      }
      case "free_snack": {
        const snacksInCart = cart.filter((item) => isSnack(item.id));
        if (snacksInCart.length === 0) return 0;
        const maxPriceSnack = Math.max(...snacksInCart.map((item) => item.price));
        return maxPriceSnack;
      }
      default:
        return 0;
    }
  };

  const executeCheckout = async () => {
    try {
      const discountVal = getVoucherDiscountValue();
      const finalPrice = Math.max(0, cartTotal - discountVal);
      
      const newOrderData = {
        customerId,
        customerName,
        tableNumber,
        items: cart,
        totalPrice: cartTotal, // Store original subtotal
        discountApplied: discountVal,
        appliedVoucherId: selectedVoucher ? selectedVoucher.id : null,
        status: "pending" as OrderStatus,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      // Add to Firestore
      const docRef = await addDoc(collection(db, "orders"), newOrderData);
      
      // Consume voucher if applied
      if (selectedVoucher) {
        const voucherRef = doc(db, "vouchers", selectedVoucher.id);
        await updateDoc(voucherRef, {
          status: "used",
          usedAt: serverTimestamp(),
        });
        setSelectedVoucher(null);
      }

      // Clear cart
      setCart([]);
      
      // Direct user to active orders dashboard
      setActiveTab("history");
      onNewNotification(
        `Pesanan berhasil dikirim ke kasir! ID: #${docRef.id.slice(-6)}`,
        "success"
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, "orders");
    }
  };

  // Cancel order (only allowed if status matches 'pending')
  const handleCancelOrder = (orderId: string) => {
    const orderToCancel = myOrders.find((o) => o.id === orderId);
    if (!orderToCancel) return;

    if (orderToCancel.status !== "pending") {
      onNewNotification("Pesanan telah diproses atau sudah diterima kasir, tidak bisa dibatalkan lagi!", "warning");
      return;
    }

    setOrderIdToCancel(orderId);
  };

  const executeCancelOrder = async () => {
    if (!orderIdToCancel) return;
    const orderId = orderIdToCancel;
    setOrderIdToCancel(null);

    try {
      const orderToCancel = myOrders.find((o) => o.id === orderId);
      const orderRef = doc(db, "orders", orderId);
      await updateDoc(orderRef, {
        status: "cancelled",
        updatedAt: serverTimestamp(),
      });

      // Restore voucher if any was used
      if (orderToCancel && orderToCancel.appliedVoucherId) {
        try {
          const voucherRef = doc(db, "vouchers", orderToCancel.appliedVoucherId);
          await updateDoc(voucherRef, {
            status: "available",
            usedAt: null,
          });
          onNewNotification(`Pesanan dibatalkan. Voucher Anda dikembalikan ke akun!`, "warning");
        } catch (vErr) {
          console.error("Gagal mengembalikan voucher:", vErr);
          onNewNotification(`Pesanan berhasil dibatalkan.`, "warning");
        }
      } else {
        onNewNotification(`Pesanan berhasil dibatalkan.`, "warning");
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const handleRedeemReward = async (reward: RewardItem) => {
    if (!loyaltyAccount) return;
    if (loyaltyAccount.points < reward.pointsCost) {
      onNewNotification("Poin Anda tidak mencukupi untuk menukarkan reward ini!", "warning");
      return;
    }

    try {
      // 1. Create a Voucher document
      const voucherId = `v_${Math.random().toString(36).substring(2, 9)}`;
      const randCode = `SENJA-${reward.type.toUpperCase().replace("_", "")}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      
      const newVoucher = {
        id: voucherId,
        customerId,
        type: reward.type,
        title: reward.title,
        code: randCode,
        pointsCost: reward.pointsCost,
        status: "available",
        createdAt: new Date(), // Local Date for quick instantaneous render
      };

      const accountRef = doc(db, "loyalty_accounts", customerId);
      const voucherRef = doc(db, "vouchers", voucherId);
      
      const historyId = `lh_${Math.random().toString(36).substring(2, 10)}`;
      const historyRef = doc(db, "loyalty_history", historyId);

      const nextPoints = loyaltyAccount.points - reward.pointsCost;
      const nextRedeemedTotal = (loyaltyAccount.redeemedPointsTotal || 0) + reward.pointsCost;

      await setDoc(voucherRef, newVoucher);
      await setDoc(historyRef, {
        customerId,
        type: "redeem",
        points: -reward.pointsCost,
        description: `Menukarkan ${reward.pointsCost} Poin dengan "${reward.title}"`,
        createdAt: new Date(),
      });
      await updateDoc(accountRef, {
        points: nextPoints,
        redeemedPointsTotal: nextRedeemedTotal,
        updatedAt: serverTimestamp(),
      });

      onNewNotification(`Berhasil menukarkan reward! Kupon "${reward.title}" tersedia di tab Voucher Saya.`, "success");
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `loyalty_accounts/${customerId}`);
    }
  };

  // Filters Calculation
  const filteredMenu = INITIAL_MENU.filter((item) => {
    const categoryMatches = selectedCategory === "All" || item.category === selectedCategory;
    const searchMatches =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase());
    return categoryMatches && searchMatches;
  });

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Status Stepper Visual Generator
  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case "pending":
        return {
          label: "Menunggu Kasir",
          color: "bg-amber-100 text-amber-800 border-amber-200",
          icon: <Clock className="w-4.5 h-4.5 text-amber-600 animate-spin" style={{ animationDuration: "3s" }} />,
        };
      case "accepted":
        return {
          label: "Diterima Kasir",
          color: "bg-indigo-100 text-indigo-800 border-indigo-200",
          icon: <CheckCircle2 className="w-4.5 h-4.5 text-indigo-600" />,
        };
      case "preparing":
        return {
          label: "Sedang Dibuat",
          color: "bg-sky-100 text-sky-800 border-sky-200",
          icon: <Coffee className="w-4.5 h-4.5 text-sky-600 animate-bounce" />,
        };
      case "ready":
        return {
          label: "Siap Diambil!",
          color: "bg-emerald-100 text-emerald-800 border-emerald-300 animate-pulse",
          icon: <Sparkles className="w-4.5 h-4.5 text-emerald-600 animate-ping" />,
        };
      case "completed":
        return {
          label: "Selesai",
          color: "bg-stone-100 text-stone-600 border-stone-200",
          icon: <CheckCircle2 className="w-4.5 h-4.5 text-stone-500" />,
        };
      case "cancelled":
        return {
          label: "Dibatalkan",
          color: "bg-rose-100 text-rose-800 border-rose-200",
          icon: <XCircle className="w-4.5 h-4.5 text-rose-600" />,
        };
    }
  };

  const renderCartContent = (isMobileLayout = false) => {
    return (
      <div className={`bg-white space-y-5 ${isMobileLayout ? "" : "p-6 rounded-3xl border border-stone-105 shadow-sm sticky top-24"}`}>
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <h3 className="font-bold text-lg text-stone-900 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-600 animate-bounce" style={{ animationDuration: "3s" }} />
            Keranjang Belanja
          </h3>
          <div className="flex items-center gap-2">
            <span className="bg-amber-100 text-amber-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
              {cart.reduce((sum, item) => sum + item.quantity, 0)} item
            </span>
            {isMobileLayout && (
              <button
                onClick={() => setIsMobileCartOpen(false)}
                className="p-1.5 text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {cart.length > 0 ? (
          <>
            {/* Cart Items List */}
            <div className={`space-y-4 overflow-y-auto pr-1 ${isMobileLayout ? "max-h-[50vh]" : "max-h-[360px]"}`}>
              {cart.map((cartItem) => (
                <div key={cartItem.id} className="border-b border-stone-100 pb-3.5 last:border-0 last:pb-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-stone-800 text-sm">{cartItem.name}</h4>
                      <p className="text-xs font-mono font-medium text-stone-400 mt-0.5">
                        Rp {cartItem.price.toLocaleString("id-ID")}
                      </p>
                    </div>
                    
                    {/* Trash button */}
                    <button
                      onClick={() => removeFromCart(cartItem.id, cartItem.name)}
                      className="p-1 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Quantity Adjusters + Note Trigger */}
                  <div className="flex items-center justify-between mt-3 gap-2">
                    {/* Note Button */}
                    <div className="flex-1">
                      {activeNoteId === cartItem.id ? (
                        <div className="flex gap-2.5 items-center mt-2.5 bg-stone-50 p-2 rounded-xl">
                          <input
                            type="text"
                            placeholder="Catatan (exp: es dikit)"
                            value={tempNote}
                            onChange={(e) => setTempNote(e.target.value)}
                            className="text-xs px-2.5 py-1.5 border border-stone-200 rounded-lg bg-white flex-1 focus:ring-1 focus:ring-amber-500"
                          />
                          <button
                            onClick={() => handleSaveNote(cartItem.id)}
                            className="bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg transition"
                          >
                            OK
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => openNoteInput(cartItem.id, cartItem.notes || "")}
                          className="text-stone-400 hover:text-amber-700 text-[11px] font-medium underline cursor-pointer"
                        >
                          {cartItem.notes ? `Note: "${cartItem.notes}"` : "+ Tambah Catatan"}
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2 bg-stone-100 px-2 py-1 rounded-lg">
                      <button
                        onClick={() => updateQuantity(cartItem.id, -1)}
                        className="p-0.5 text-stone-500 hover:text-stone-800 transition"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-mono font-bold px-1">{cartItem.quantity}</span>
                      <button
                        onClick={() => updateQuantity(cartItem.id, 1)}
                        className="p-0.5 text-stone-500 hover:text-stone-800 transition"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary Pricing */}
            <div className="border-t border-stone-100 pt-4 space-y-2">
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span>Subtotal</span>
                <span className="font-mono">Rp {cartTotal.toLocaleString("id-ID")}</span>
              </div>

              {selectedVoucher && (
                <div className="flex items-center justify-between text-xs text-emerald-700 font-semibold bg-emerald-50/50 p-2 rounded-xl border border-emerald-200/50">
                  <span className="flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-emerald-600" />
                    Kupon: {selectedVoucher.title}
                  </span>
                  <span className="font-mono font-bold">-Rp {getVoucherDiscountValue().toLocaleString("id-ID")}</span>
                </div>
              )}

              <div className="flex items-center justify-between text-xs text-stone-500">
                <span>Pajak PB1 (10%)</span>
                <span className="font-mono">Rp {Math.max(0, (cartTotal - getVoucherDiscountValue()) * 0.1).toLocaleString("id-ID")}</span>
              </div>
              <div className="flex items-center justify-between text-sm font-bold text-stone-900 pt-1.5 border-t border-stone-55">
                <span>Total Bayar</span>
                <span className="font-mono text-amber-700">Rp {Math.max(0, (cartTotal - getVoucherDiscountValue()) * 1.1).toLocaleString("id-ID")}</span>
              </div>
            </div>

            {/* Checkout Button */}
            <button
              id={isMobileLayout ? "order-now-btn-mobile" : "order-now-btn"}
              onClick={() => {
                if (isMobileLayout) {
                  setIsMobileCartOpen(false);
                }
                handleCheckout();
              }}
              className="w-full py-4 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-semibold text-sm rounded-xl transition duration-300 shadow-md shadow-amber-600/10 active:scale-98 cursor-pointer flex items-center justify-center gap-2 animate-pulse"
            >
              Kirim Pesanan (Hubungkan Dapur)
            </button>
          </>
        ) : (
          <div className="text-center py-10">
            <div className="p-3 bg-stone-50 inline-flex rounded-full text-stone-300 mb-2">
              <ShoppingCart className="w-6 h-6" />
            </div>
            <p className="text-xs text-stone-500 font-medium font-semibold text-stone-700">Keranjang masih kosong.</p>
            <p className="text-[11px] text-stone-400 mt-1">Pilih dan ketuk tombol "Pesan" di daftar menu.</p>
          </div>
        )}
      </div>
    );
  };

  // Login Screen if no session active
  if (!isSessionActive) {
    return (
      <div id="customer-setup-container" className="max-w-md mx-auto my-12 p-8 bg-white rounded-3xl border border-stone-100 shadow-xl">
        <div className="text-center mb-8">
          <div className="inline-flex p-4 bg-amber-50 rounded-2xl text-amber-600 mb-4 shadow-inner">
            <Coffee className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-stone-900">Selamat Datang di Kopi Senja 👋</h2>
          <p className="text-stone-500 text-sm mt-2">
            Nikmati kemudahan memesan kopi favorit Anda langsung dari meja menggunakan sistem digital PWA kami.
          </p>
        </div>

        <form onSubmit={handleSetupSession} className="space-y-5">
          <div>
            <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
              Nama Anda
            </label>
            <input
              id="customer-name-input"
              type="text"
              required
              value={inputName}
              onChange={(e) => setInputName(e.target.value)}
              placeholder="Contoh: Budi, Sarah, Denny..."
              className="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-stone-955 bg-stone-50/50"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-2">
              Nomor Meja
            </label>
            <select
              id="customer-table-select"
              required
              value={inputTable}
              onChange={(e) => setInputTable(e.target.value)}
              className="w-full px-4 py-3 border border-stone-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-stone-955 bg-stone-50/50"
            >
              <option value="">-- Pilih Meja Anda --</option>
              {Array.from({ length: 15 }, (_, i) => i + 1).map((n) => (
                <option key={n} value={String(n)}>
                  Meja {n}
                </option>
              ))}
            </select>
          </div>

          <button
            id="start-session-btn"
            type="submit"
            className="w-full py-4.5 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-semibold text-sm rounded-xl transition duration-300 shadow-md shadow-amber-600/10 active:scale-98 flex items-center justify-center gap-2"
          >
            Mulai Pesan Sekarang
            <ChevronRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    );
  }

  // Active Main Customer Screen
  return (
    <div id="customer-view-root" className="max-w-7xl mx-auto px-4 py-6">
      {/* Session Header Status */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-stone-100 p-4 rounded-2xl mb-6 border border-stone-200/50 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-600/10 text-amber-700 rounded-xl font-mono text-xs font-bold ring-1 ring-amber-600/20">
            Meja {tableNumber}
          </div>
          <div>
            <p className="text-xs text-stone-500">Nama Pelanggan:</p>
            <p className="text-sm font-semibold text-stone-800">{customerName}</p>
          </div>
        </div>

        {/* Buttons: Menu / History / Loyalty Tab selection & session logout */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            id="tab-menu-btn"
            onClick={() => setActiveTab("menu")}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition ${
              activeTab === "menu"
                ? "bg-amber-600 text-white shadow-sm"
                : "bg-white text-stone-600 border border-stone-200 hover:bg-stone-50"
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            Katalog Menu
          </button>
          <button
            id="tab-orders-btn"
            onClick={() => setActiveTab("history")}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold relative transition ${
              activeTab === "history"
                ? "bg-amber-600 text-white shadow-sm"
                : "bg-white text-stone-600 border border-stone-200 hover:bg-stone-50"
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Riwayat Pesanan
            {myOrders.some((o) => ["pending", "accepted", "preparing", "ready"].includes(o.status)) && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 border-2 border-white rounded-full animate-ping"></span>
            )}
          </button>
          <button
            id="tab-loyalty-btn"
            onClick={() => setActiveTab("loyalty")}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold relative transition ${
              activeTab === "loyalty"
                ? "bg-amber-600 text-white shadow-sm"
                : "bg-white text-stone-600 border border-stone-200 hover:bg-stone-50"
            }`}
          >
            <Gift className="w-3.5 h-3.5 text-amber-500" />
            Reward & Voucher
            {loyaltyAccount !== null && (
              <span className="bg-amber-50 text-amber-700 text-[10px] px-1.5 py-0.5 rounded-full font-bold ml-1 border border-amber-200/50">
                {loyaltyAccount.points || 0} Pts
              </span>
            )}
          </button>
          <button
            id="logout-session-btn"
            onClick={handleClearSession}
            title="Keluar Meja"
            className="p-2 text-stone-400 hover:text-stone-600 rounded-xl border border-stone-200 bg-white"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {activeTab === "menu" ? (
        /* Catalog layout + Cart Sidebar */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Menu Catalog Section (2 Cols wide) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Filter Categories and Search Input */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex flex-nowrap overflow-x-auto gap-2 pb-2 md:pb-0 scrollbar-none">
                {["All", "Classic Coffee", "Signature Coffee", "Non-Coffee", "Snack & Food"].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap border transition duration-200 ${
                      selectedCategory === cat
                        ? "bg-stone-900 border-stone-900 text-white"
                        : "bg-white border-stone-200 text-stone-600 hover:bg-stone-50"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  placeholder="Cari kopi, snack..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-stone-200 rounded-xl text-xs w-full md:w-60 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 bg-white"
                />
              </div>
            </div>

            {/* Menu Items Grid */}
            {filteredMenu.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {filteredMenu.map((item) => {
                  const cartItem = cart.find((c) => c.id === item.id);
                  return (
                    <div
                      key={item.id}
                      className="bg-white rounded-2xl border border-stone-105 shadow-sm overflow-hidden flex flex-col justify-between group hover:shadow-md transition-all duration-350"
                    >
                      <div>
                        {/* Aspect Ratio 16/9 Image */}
                        <div className="relative h-44 overflow-hidden bg-stone-100">
                          <img
                            src={item.image}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                          />
                          <span className="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-[10px] font-bold text-white uppercase tracking-wider bg-black/60 shadow-sm backdrop-blur-sm">
                            {item.category}
                          </span>
                        </div>

                        {/* Details */}
                        <div className="p-4.5">
                          <h3 className="font-bold text-stone-900 text-base mb-1">{item.name}</h3>
                          <p className="text-stone-500 text-xs leading-relaxed mb-2 line-clamp-2">
                            {item.description}
                          </p>
                        </div>
                      </div>

                      {/* CTA Panel */}
                      <div className="p-4.5 pt-0 border-t border-stone-50 flex items-center justify-between">
                        <span className="font-mono text-sm font-bold text-amber-700">
                          Rp {item.price.toLocaleString("id-ID")}
                        </span>

                        {cartItem ? (
                          <div className="flex items-center gap-2 bg-stone-105 p-1 rounded-lg">
                            <button
                              onClick={() => updateQuantity(item.id, -1)}
                              className="p-1 rounded-md text-stone-603 hover:bg-stone-200 transition"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="text-xs font-mono font-semibold px-2">
                              {cartItem.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.id, 1)}
                              className="p-1 rounded-md text-stone-603 hover:bg-stone-200 transition"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => addToCart(item)}
                            className="flex items-center gap-1 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs px-3.5 py-2 rounded-lg transition active:scale-95 shadow-sm shadow-amber-600/5 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                            Pesan
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-stone-50/50 p-12 text-center rounded-2xl border border-stone-200/50">
                <AlertCircle className="w-8 h-8 text-stone-400 mx-auto mb-3" />
                <p className="text-sm font-medium text-stone-600">Menu tidak ditemukan</p>
                <p className="text-xs text-stone-400 mt-1">Coba sesuaikan kata kunci atau kategori pencarian Anda.</p>
              </div>
            )}
          </div>

          {/* Cart Section (1 Col wide) - Hidden on mobile, shown on large screens */}
          <div className="hidden lg:block lg:col-span-1">
            {renderCartContent(false)}
          </div>
        </div>
      ) : (
        /* History Dashboard Section */
        <div className="space-y-6">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <ClipboardList className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-lg text-stone-900">Riwayat Pesanan Anda</h3>
          </div>

          {myOrders.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {myOrders.map((order) => {
                const b = getStatusBadge(order.status);
                const isPending = order.status === "pending";

                return (
                  <div
                    key={order.id}
                    className="bg-white border border-stone-110 shadow-sm rounded-2xl overflow-hidden p-5 space-y-4 flex flex-col justify-between"
                  >
                    <div className="space-y-3.5">
                      {/* Order Ref & Badge */}
                      <div className="flex items-start justify-between gap-2 border-b border-stone-50 pb-3">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs text-stone-400 font-medium">Order ID:</span>
                            <span className="text-xs font-mono font-bold text-stone-700">#{order.id.slice(-6).toUpperCase()}</span>
                          </div>
                          <span className="text-[11px] text-stone-400 mt-1 block">
                            Dipesan: {order.createdAt instanceof Date ? order.createdAt.toLocaleTimeString() : "Baru saja"}
                          </span>
                        </div>

                        {/* Status Label and Icon */}
                        <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold border ${b.color}`}>
                          {b.icon}
                          {b.label}
                        </div>
                      </div>

                      {/* Items details */}
                      <div className="space-y-2">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between text-xs text-stone-700">
                            <div>
                              <span className="font-semibold text-stone-900">{item.quantity}x</span> {item.name}
                              {item.notes && (
                                <span className="block text-[10px] text-amber-600 font-medium italic mt-0.5">
                                  * Catatan: {item.notes}
                                </span>
                              )}
                            </div>
                            <span className="font-mono text-stone-500">
                              Rp {(item.price * item.quantity).toLocaleString("id-ID")}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Total Pricing / Tax included calculated */}
                      <div className="border-t border-stone-50 pt-3 flex items-center justify-between">
                        <span className="text-xs text-stone-500 font-medium">Total Tagihan (incl. PB1)</span>
                        <span className="font-mono font-bold text-amber-700 text-sm">
                          Rp {(order.totalPrice * 1.1).toLocaleString("id-ID")}
                        </span>
                      </div>
                    </div>

                    {/* Action panel (Cancel Order) */}
                    <div>
                      {isPending ? (
                        <button
                          id={`cancel-order-btn-${order.id}`}
                          onClick={() => handleCancelOrder(order.id)}
                          className="w-full py-2.5 border border-rose-200 hover:bg-rose-50 text-rose-600 rounded-xl text-xs font-semibold uppercase tracking-wider transition active:scale-97 cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          Batalkan Pesanan
                        </button>
                      ) : (
                        <div className="bg-stone-50 p-2.5 rounded-xl border border-stone-200/50 flex items-center gap-2 text-stone-505">
                          <CheckCircle2 className="w-4 h-4 text-stone-400" />
                          <span className="text-[11px] font-medium">
                            {order.status === "cancelled"
                              ? "Pesanan Anda telah dibatalkan."
                              : "Diterima kasir. Pesanan sedang diproses & tidak bisa dibatalkan."}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-stone-50/50 p-12 text-center rounded-2xl border border-stone-200/50">
              <ClipboardList className="w-8 h-8 text-stone-400 mx-auto mb-3 animate-pulse" />
              <p className="text-sm font-medium text-stone-600">Belum ada riwayat pemesanan</p>
              <p className="text-xs text-stone-400 mt-1">Anda belum melakukan pesanan di meja ini hari ini.</p>
            </div>
          )}
        </div>
      )}

      {activeTab === "loyalty" && (
        <div id="loyalty-portal" className="space-y-8 animate-in fade-in duration-200">
          {/* Header Stats card */}
          <div className="bg-gradient-to-br from-amber-600 to-amber-800 text-white p-6 md:p-8 rounded-3xl shadow-lg relative overflow-hidden">
            <div className="absolute right-0 top-0 opacity-10 translate-x-12 -translate-y-12">
              <Gift className="w-96 h-96" />
            </div>
            
            <div className="max-w-md relative z-10">
              <div className="flex items-center gap-2 bg-white/20 px-3 py-1.5 rounded-full text-xs font-semibold w-fit mb-4">
                <Award className="w-4 h-4 text-amber-200" />
                Loyalty Member Kopi Senja
              </div>
              <h3 className="text-xs font-semibold opacity-80 uppercase tracking-widest">Saldo Poin Anda</h3>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-4xl md:text-5xl font-black font-mono tracking-tight text-white drop-shadow-sm">
                  {loyaltyAccount?.points || 0}
                </span>
                <span className="text-xs font-bold text-amber-200 uppercase tracking-wider bg-white/10 px-2 py-0.5 rounded-md">Poin Barista</span>
              </div>
              <p className="text-xs opacity-90 mt-4 leading-relaxed bg-black/10 p-3 rounded-xl border border-white/10">
                Poin diperoleh otomatis sebesar <strong className="text-amber-200">1 Poin setiap Rp 1.000</strong> dari pesanan Anda yang telah selesai. Poin dapat ditukarkan untuk potongan diskon langsung atau minuman gratis!
              </p>
            </div>
            
            <div className="mt-6 md:mt-0 md:absolute md:right-8 md:bottom-8 bg-amber-950/40 border border-white/10 backdrop-blur-md p-4 rounded-2xl flex items-center gap-3">
              <Coins className="w-10 h-10 text-amber-300 animate-pulse" />
              <div>
                <p className="text-[10px] text-amber-100 uppercase tracking-wider font-bold">Rincian Akumulasi</p>
                <div className="flex gap-4 mt-1">
                  <div>
                    <span className="text-[10px] text-stone-300 block leading-none">Total Didapat</span>
                    <span className="font-bold font-mono text-xs text-white">+{loyaltyAccount?.earnedPointsTotal || 0}</span>
                  </div>
                  <div className="border-l border-white/10 pl-3">
                    <span className="text-[10px] text-stone-300 block leading-none">Telah Ditukar</span>
                    <span className="font-bold font-mono text-xs text-stone-200">-{loyaltyAccount?.redeemedPointsTotal || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Catalog of Rewards */}
            <div className="lg:col-span-2 space-y-6">
              <h4 className="font-bold text-base text-stone-900 flex items-center gap-2">
                <Gift className="w-5 h-5 text-amber-600 animate-pulse" />
                Penukaran Reward Kopi Senja
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {REWARD_ITEMS.map((reward) => {
                  const currentPoints = loyaltyAccount?.points || 0;
                  const isAffordable = currentPoints >= reward.pointsCost;
                  
                  return (
                    <div 
                      key={reward.id} 
                      className={`bg-white border rounded-2xl p-4 flex flex-col justify-between transition duration-200 shadow-sm hover:shadow-md ${
                        isAffordable 
                          ? "border-stone-200" 
                          : "border-stone-100 bg-stone-50/60"
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <span className="bg-amber-100 text-amber-900 text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                            {reward.pointsCost} Poin
                          </span>
                          <span className="text-[10px] text-stone-400 font-mono">Katalog Item</span>
                        </div>
                        <h5 className="font-bold text-sm text-stone-800">{reward.title}</h5>
                        <p className="text-xs text-stone-500 mt-1 line-clamp-2 leading-relaxed">
                          {reward.description}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
                        <span className="text-[10px] font-medium text-stone-400">
                          {isAffordable ? "Poin mencukupi" : `Butuh ${reward.pointsCost - currentPoints} poin lagi`}
                        </span>
                        
                        <button
                          onClick={() => handleRedeemReward(reward)}
                          disabled={!isAffordable}
                          className={`px-4 py-2 rounded-xl text-xs font-bold transition duration-200 cursor-pointer ${
                            isAffordable
                              ? "bg-amber-600 hover:bg-amber-700 active:scale-95 text-white"
                              : "bg-stone-200 text-stone-400 cursor-not-allowed"
                          }`}
                        >
                          Tukarkan Poin
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* My Vouchers Drawer + Points logs */}
            <div className="space-y-6">
              {/* Vouchers section */}
              <div className="bg-white border border-stone-200 p-5 rounded-2xl space-y-4 shadow-sm">
                <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2 border-b border-stone-100 pb-3">
                  <Tag className="w-4 h-4 text-amber-600 animate-pulse" />
                  Voucher Saya ({myVouchers.filter(v => v.status === "available").length})
                </h4>

                {myVouchers.length > 0 ? (
                  <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
                    {myVouchers.map((v) => {
                      const isVoucherSelected = selectedVoucher?.id === v.id;
                      const isUsed = v.status === "used";
                      
                      return (
                        <div 
                          key={v.id} 
                          className={`p-3 rounded-xl border transition duration-150 relative overflow-hidden ${
                            isUsed 
                              ? "bg-stone-50 border-stone-100 opacity-60" 
                              : isVoucherSelected
                              ? "border-amber-500 bg-amber-50/20 ring-1 ring-amber-500/20"
                              : "border-stone-200 bg-white hover:border-amber-400"
                          }`}
                        >
                          {/* Ticket edge overlay cuts */}
                          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-2 h-4 bg-stone-100 rounded-r-full border-r border-stone-200"></div>
                          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-4 bg-stone-100 rounded-l-full border-l border-stone-200"></div>

                          <div className="pl-2 pr-2">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-[9px] font-bold font-mono text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200/50">
                                {v.code}
                              </span>
                              <span className="text-[10px] text-stone-400 capitalize bg-stone-100 px-1.5 py-0.5 rounded font-medium">
                                {isUsed ? "Terpakai" : "Aktif"}
                              </span>
                            </div>
                            <h5 className="font-bold text-xs text-stone-800">{v.title}</h5>

                            {!isUsed && (
                              <div className="mt-3 flex justify-end">
                                {isVoucherSelected ? (
                                  <button
                                    onClick={() => setSelectedVoucher(null)}
                                    className="px-2.5 py-1 text-[10px] font-bold bg-amber-600 hover:bg-amber-700 text-white rounded-lg transition"
                                  >
                                    Batal Pakai
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => {
                                      setSelectedVoucher(v);
                                      onNewNotification(`Kupon "${v.title}" berhasil dipasang ke keranjang!`, "success");
                                    }}
                                    className="px-2.5 py-1 text-[10px] font-bold border border-amber-600 hover:bg-amber-50 text-amber-700 rounded-lg transition"
                                  >
                                    Pasang ke Keranjang
                                  </button>
                                )}
                              </div>
                            )}

                            {isUsed && v.usedAt && (
                              <p className="text-[9px] text-stone-400 text-right mt-1.5">
                                Digunakan pada: {v.usedAt instanceof Date ? v.usedAt.toLocaleDateString("id-ID") : new Date(v.usedAt).toLocaleDateString("id-ID")}
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-6 bg-stone-50/50 rounded-xl border border-dashed border-stone-200">
                    <Tag className="w-5 h-5 text-stone-300 mx-auto mb-2" />
                    <p className="text-[11px] text-stone-500">Anda tidak memiliki voucher.</p>
                    <p className="text-[10px] text-stone-400 mt-0.5">Tukarkan poin aktif Anda di katalog reward!</p>
                  </div>
                )}
              </div>

              {/* Points History logs */}
              <div className="bg-white border border-stone-200 p-5 rounded-2xl space-y-4 shadow-sm">
                <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2 border-b border-stone-100 pb-3">
                  <History className="w-4 h-4 text-amber-600" />
                  Aliran Poin
                </h4>

                {loyaltyHistory.length > 0 ? (
                  <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
                    {loyaltyHistory.map((log) => {
                      const isAdd = log.points > 0;
                      return (
                        <div key={log.id} className="flex justify-between items-start gap-2.5 pb-2.5 border-b border-stone-50 last:border-0 last:pb-0">
                          <div>
                            <p className="text-xs font-semibold text-stone-750 leading-tight">
                              {log.description}
                            </p>
                            <p className="text-[9px] text-stone-400 mt-0.5 font-mono">
                              {log.createdAt instanceof Date ? log.createdAt.toLocaleString("id-ID") : new Date(log.createdAt).toLocaleString("id-ID")}
                            </p>
                          </div>
                          
                          <span className={`font-mono text-[11px] font-extrabold shrink-0 px-2 py-0.5 rounded-md ${
                            isAdd 
                              ? "text-emerald-700 bg-emerald-50 border border-emerald-100" 
                              : "text-amber-750 bg-amber-50 border border-amber-100"
                          }`}>
                            {isAdd ? "+" : ""}{log.points}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-6 bg-stone-50/50 rounded-xl border border-dashed border-stone-200">
                    <History className="w-5 h-5 text-stone-300 mx-auto mb-1.5" />
                    <p className="text-[10px] text-stone-400 font-medium">Belum ada aktivitas poin saat ini.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Checkout Confirmation Modal */}
      {showConfirmCheckout && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-xl border border-stone-105 animate-in fade-in duration-200">
            <div className="flex items-center gap-3 text-amber-600 mb-4">
              <AlertCircle className="w-6 h-6 shrink-0 font-bold" />
              <h4 className="font-bold text-stone-900 text-lg">Konfirmasi Pesanan</h4>
            </div>
            <p className="text-stone-600 text-sm leading-relaxed mb-6">
              Apa Anda yakin ingin memesan? Setelah kasir menerima pesanan, pesanan tidak dapat dibatalkan lagi.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowConfirmCheckout(false)}
                className="px-4 py-2 text-stone-500 hover:text-stone-800 text-sm font-semibold hover:bg-stone-100 rounded-xl transition cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  setShowConfirmCheckout(false);
                  executeCheckout();
                }}
                className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white text-sm font-semibold rounded-xl transition shadow-md shadow-amber-600/10 cursor-pointer"
              >
                Ya, Kirim Pesanan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Order Confirmation Modal */}
      {orderIdToCancel && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-xl border border-stone-105 animate-in fade-in duration-200">
            <div className="flex items-center gap-3 text-rose-600 mb-4">
              <AlertCircle className="w-6 h-6 shrink-0 font-bold" />
              <h4 className="font-bold text-stone-900 text-lg">Batalkan Pesanan</h4>
            </div>
            <p className="text-stone-600 text-sm leading-relaxed mb-6">
              Apakah Anda yakin ingin membatalkan pesanan ini? Aksi ini tidak dapat diubah setelah selesai.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setOrderIdToCancel(null)}
                className="px-4 py-2 text-stone-500 hover:text-stone-800 text-sm font-semibold hover:bg-stone-100 rounded-xl transition cursor-pointer"
              >
                Kembali
              </button>
              <button
                id="confirm-cancel-order-btn"
                onClick={executeCancelOrder}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white text-sm font-semibold rounded-xl transition shadow-md shadow-rose-600/10 cursor-pointer"
              >
                Ya, Batalkan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Button (FAB) for mobile screen */}
      {activeTab === "menu" && (
        <button
          onClick={() => setIsMobileCartOpen(true)}
          className="fixed bottom-6 right-6 z-40 lg:hidden flex items-center justify-center w-14 h-14 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white rounded-full shadow-lg shadow-amber-600/30 active:scale-95 transition cursor-pointer"
          title="Lihat Keranjang"
        >
          <div className="relative">
            <ShoppingCart className="w-6 h-6" />
            {cart.length > 0 && (
              <span className="absolute -top-3.5 -right-3 px-2 py-0.5 text-[10px] font-bold bg-rose-500 text-white rounded-full border border-white flex items-center justify-center animate-bounce">
                {cart.reduce((sum, item) => sum + item.quantity, 0)}
              </span>
            )}
          </div>
        </button>
      )}

      {/* Mobile Cart Bottom Sheet / Sidebar Overlay Drawer */}
      {isMobileCartOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden flex flex-col justify-end"
          onClick={() => setIsMobileCartOpen(false)}
        >
          <div 
            className="bg-white rounded-t-3xl p-6 shadow-xl border-t border-stone-105 max-h-[90vh] overflow-y-auto animate-in slide-in-from-bottom duration-250"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Handle/bar indicator for visual alignment */}
            <div className="w-12 h-1.5 bg-stone-200 rounded-full mx-auto mb-5 cursor-pointer" onClick={() => setIsMobileCartOpen(false)}></div>
            {renderCartContent(true)}
          </div>
        </div>
      )}
    </div>
  );
}
