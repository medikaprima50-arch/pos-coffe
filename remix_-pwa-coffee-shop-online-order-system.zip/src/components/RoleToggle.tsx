import React from "react";
import { Coffee, User, Settings } from "lucide-react";

interface RoleToggleProps {
  currentRole: "customer" | "cashier";
  onRoleChange: (role: "customer" | "cashier") => void;
}

export default function RoleToggle({ currentRole, onRoleChange }: RoleToggleProps) {
  return (
    <header className="sticky top-0 z-50 bg-stone-900/95 backdrop-blur-md border-b border-stone-800 text-stone-100 shadow-lg px-4 py-3">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-600 rounded-xl shadow-md text-stone-100 flex items-center justify-center">
            <Coffee className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h1 className="font-sans text-xl font-bold tracking-tight text-white flex items-center gap-2">
              Kopi Senja{" "}
              <span className="text-xs bg-amber-600/20 text-amber-400 px-2 py-0.5 rounded-full font-mono border border-amber-500/30">
                PWA Order
              </span>
            </h1>
            <p className="text-xs text-stone-400">Digital Specialty Coffee & Eatery</p>
          </div>
        </div>

        {/* Role Selectors */}
        <div className="flex items-center gap-2 bg-stone-950 p-1 rounded-xl border border-stone-850">
          <button
            id="role-customer-btn"
            onClick={() => onRoleChange("customer")}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg transition-all duration-300 ${
              currentRole === "customer"
                ? "bg-amber-600 text-white shadow-md shadow-amber-600/10"
                : "text-stone-400 hover:text-stone-200"
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Portal Pelanggan
          </button>
          <button
            id="role-cashier-btn"
            onClick={() => onRoleChange("cashier")}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg transition-all duration-300 ${
              currentRole === "cashier"
                ? "bg-stone-800 text-amber-400 shadow-md border border-stone-700/50"
                : "text-stone-400 hover:text-stone-200"
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            Dashboard Kasir
          </button>
        </div>
      </div>
    </header>
  );
}
