import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";
import { Order, OrderStatus } from "../types";
import { handleFirestoreError, OperationType } from "../utils/firestore-error";
import {
  Coffee,
  Check,
  ChevronRight,
  TrendingUp,
  CreditCard,
  Hash,
  Users,
  Timer,
  Bell,
  X,
  Volume2,
  VolumeX,
  CheckCircle,
  Clock,
  Play,
  Ban,
} from "lucide-react";

interface CashierViewProps {
  onNewNotification: (message: string, type: "success" | "info" | "warning") => void;
}

export default function CashierView({ onNewNotification }: CashierViewProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [filterType, setFilterType] = useState<"all" | "pending" | "active" | "completed">("active");
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Sound chime creator
  const triggerAudioChime = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      // Simple sweet chime: two tones C5 -> E5
      const playTone = (freq: number, start: number, duration: number) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.frequency.setValueAtTime(freq, start);
        gain.gain.setValueAtTime(0.12, start);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(start);
        osc.stop(start + duration);
      };
      const now = audioCtx.currentTime;
      playTone(523.25, now, 0.4); // C5
      playTone(659.25, now + 0.15, 0.5); // E5
    } catch (e) {
      console.warn("AudioContext failed or blocked by autoplay restriction:", e);
    }
  };

  // Subscribe to ALL orders in real-time
  useEffect(() => {
    const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));
    
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const orderList: Order[] = [];
        let pendingAdded = false;

        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          const obj = {
            id: docSnap.id,
            ...data,
            createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date(),
            updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : new Date(),
          } as Order;

          orderList.push(obj);
        });

        // Ring chime if a brand new "pending" order is detected
        if (orders.length > 0) {
          // Find if we have more pending orders now than before
          const currentPendings = orderList.filter((o) => o.status === "pending").map(o => o.id);
          const oldPendings = orders.filter((o) => o.status === "pending").map(o => o.id);
          const newPendings = currentPendings.filter(id => !oldPendings.includes(id));
          
          if (newPendings.length > 0) {
            triggerAudioChime();
            onNewNotification(`🔔 Pesanan baru masuk dari Meja ${orderList.find(o => o.id === newPendings[0])?.tableNumber}!`, "info");
          }
        }

        setOrders(orderList);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, "orders");
      }
    );

    return () => unsubscribe();
  }, [orders.length, soundEnabled]);

  // Execute State transitions on individual orders
  const transitionOrderStatus = async (orderId: string, currentStatus: OrderStatus) => {
    let nextStatus: OrderStatus = currentStatus;
    let messageText = "";

    switch (currentStatus) {
      case "pending":
        nextStatus = "accepted";
        messageText = "Pesanan telah diterima dan diteruskan ke dapur.";
        break;
      case "accepted":
        nextStatus = "preparing";
        messageText = "Status diubah menjadi 'Sedang Dibuat'.";
        break;
      case "preparing":
        nextStatus = "ready";
        messageText = "Status diubah menjadi 'Siap Diambil!'. Barista selesai membikin hidangan.";
        break;
      case "ready":
        nextStatus = "completed";
        messageText = "Pesanan selesai diserahkan ke pelanggan.";
        break;
    }

    if (nextStatus === currentStatus) return;

    try {
      const orderRef = doc(db, "orders", orderId);
      await updateDoc(orderRef, {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });

      // Loyalty program credit if order is completed
      if (nextStatus === "completed") {
        const order = orders.find((o) => o.id === orderId);
        if (order && order.customerId) {
          const calculatedSubtotal = order.totalPrice - (order.discountApplied || 0);
          const earnedPoints = Math.floor(calculatedSubtotal / 1000);
          
          if (earnedPoints > 0) {
            try {
              const accountRef = doc(db, "loyalty_accounts", order.customerId);
              const accountSnap = await getDoc(accountRef);
              
              if (accountSnap.exists()) {
                const currentData = accountSnap.data();
                const updatedPoints = (currentData.points || 0) + earnedPoints;
                const updatedEarned = (currentData.earnedPointsTotal || 0) + earnedPoints;
                
                await updateDoc(accountRef, {
                  points: updatedPoints,
                  earnedPointsTotal: updatedEarned,
                  updatedAt: serverTimestamp(),
                });

                // Add points log
                const logId = `log_${Math.random().toString(36).substring(2, 9)}`;
                const logRef = doc(db, "loyalty_history", logId);
                await setDoc(logRef, {
                  customerId: order.customerId,
                  type: "earn",
                  points: earnedPoints,
                  description: `Poin dari Pesanan #${orderId.slice(-6).toUpperCase()}`,
                  createdAt: serverTimestamp(),
                });
              }
            } catch (pErr) {
              console.error("Gagal menambahkan poin loyalitas:", pErr);
            }
          }
        }
      }

      onNewNotification(`Status Pesanan #${orderId.slice(-4)} diperbarui!`, "success");
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  // Direct cancel order (by Cashier)
  const handleCancelOrderByCashier = async (orderId: string) => {
    if (confirm("Apakah Anda yakin ingin membatalkan pesanan pelanggan ini? tindakan ini permanen.")) {
      try {
        const order = orders.find((o) => o.id === orderId);
        const orderRef = doc(db, "orders", orderId);
        await updateDoc(orderRef, {
          status: "cancelled",
          updatedAt: serverTimestamp(),
        });

        // Revert applied voucher if exists
        if (order && order.appliedVoucherId) {
          try {
            const voucherRef = doc(db, "vouchers", order.appliedVoucherId);
            await updateDoc(voucherRef, {
              status: "available",
              usedAt: null,
            });
          } catch (vErr) {
            console.error("Gagal mengembalikan voucher:", vErr);
          }
        }
        
        onNewNotification(`Pesanan #${orderId.slice(-4)} dibatalkan oleh Kasir.`, "warning");
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
      }
    }
  };

  // Analytics helper calculations
  const totalRevenue = orders
    .filter((o) => o.status === "completed")
    .reduce((sum, o) => sum + o.totalPrice * 1.1, 0); // Include Tax in totals

  const pendingCount = orders.filter((o) => o.status === "pending").length;
  const processingCount = orders.filter((o) => ["accepted", "preparing"].includes(o.status)).length;
  const readyCount = orders.filter((o) => o.status === "ready").length;

  // Filter local orders state by custom selection
  const filteredOrders = orders.filter((o) => {
    if (filterType === "pending") return o.status === "pending";
    if (filterType === "active") return ["pending", "accepted", "preparing", "ready"].includes(o.status);
    if (filterType === "completed") return ["completed", "cancelled"].includes(o.status);
    return true; // "all"
  });

  return (
    <div id="cashier-view-root" className="max-w-7xl mx-auto px-4 py-6 space-y-8">
      {/* Analytics Dashboard Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-stone-105 p-5 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Pemasukan Hari Ini</p>
            <p className="text-lg font-mono font-black text-stone-900 mt-1">
              Rp {totalRevenue.toLocaleString("id-ID")}
            </p>
          </div>
        </div>

        <div className="bg-white border border-stone-105 p-5 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-50 text-rose-600 rounded-xl">
            <Bell className="w-5 h-5 animate-swing" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Menunggu Konfirmasi</p>
            <p className="text-xl font-bold font-mono text-stone-900 mt-1">{pendingCount} Pesanan</p>
          </div>
        </div>

        <div className="bg-white border border-stone-105 p-5 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="p-3 bg-sky-50 text-sky-600 rounded-xl">
            <Timer className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Sedang Diproses</p>
            <p className="text-xl font-bold font-mono text-stone-900 mt-1">{processingCount} Pesanan</p>
          </div>
        </div>

        <div className="bg-white border border-stone-105 p-5 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle className="w-5 h-5 font-bold" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Siap Diambil</p>
            <p className="text-xl font-bold font-mono text-stone-900 mt-1">{readyCount} Pesanan</p>
          </div>
        </div>
      </div>

      {/* Control bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-stone-100 pb-5">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: "active", label: "Aktif / Berjalan" },
            { id: "pending", label: "Menunggu Kasir" },
            { id: "completed", label: "Selesai / Batal" },
            { id: "all", label: "Semua Pesanan" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold select-none border transition duration-200 ${
                filterType === tab.id
                  ? "bg-amber-600 border-amber-600 text-white shadow-sm"
                  : "bg-white border-stone-200 text-stone-605 hover:bg-stone-50"
              }`}
            >
              {tab.label}
              {tab.id === "pending" && pendingCount > 0 && (
                <span className="ml-1.5 bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                  {pendingCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Chime controls simulation helper */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="flex items-center gap-1.5 text-xs text-stone-500 hover:text-stone-700 bg-stone-100 px-3 py-2 rounded-xl border border-stone-200 transition cursor-pointer"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-emerald-600" /> Sound Ring On
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-stone-400" /> Sound Ring Off
              </>
            )}
          </button>
          <button
            onClick={triggerAudioChime}
            className="p-2 text-stone-500 hover:text-stone-700 bg-stone-100 border border-stone-200 rounded-xl"
            title="Uji Suara Lonceng Antrean"
          >
            <Play className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Orders Real-Time Kanban/Grid mapping */}
      {filteredOrders.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOrders.map((order) => {
            const hasPendingStatus = order.status === "pending";
            const dateStr = order.createdAt instanceof Date ? order.createdAt.toLocaleTimeString("id", { hour: "2-digit", minute: "2-digit" }) : "Baru saja";

            return (
              <div
                key={order.id}
                className={`bg-white border rounded-2xl overflow-hidden p-5 space-y-4 flex flex-col justify-between shadow-sm transition hover:shadow-md ${
                  order.status === "pending"
                    ? "border-amber-400 ring-2 ring-amber-400/20 animate-pulse-slow"
                    : order.status === "ready"
                    ? "border-emerald-400"
                    : "border-stone-110"
                }`}
              >
                <div className="space-y-3.5">
                  {/* Order metadata Header */}
                  <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs bg-stone-105 text-stone-700 font-bold px-2 py-0.5 rounded-lg border border-stone-200">
                          Meja {order.tableNumber}
                        </span>
                        <span className="text-[11px] font-mono font-medium text-stone-400">
                          #{order.id.slice(-5).toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm font-bold text-stone-800 mt-1">{order.customerName}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-[11px] text-stone-400 flex items-center gap-1 justify-end">
                        <Clock className="w-3 h-3" />
                        {dateStr}
                      </span>
                      {/* Sub status tag */}
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider block mt-1 ${
                          order.status === "pending"
                            ? "text-amber-600"
                            : order.status === "accepted"
                            ? "text-indigo-600"
                            : order.status === "preparing"
                            ? "text-sky-600"
                            : order.status === "ready"
                            ? "text-emerald-600"
                            : order.status === "completed"
                            ? "text-stone-400"
                            : "text-rose-600"
                        }`}
                      >
                        {order.status === "pending" && "Menunggu Kasir"}
                        {order.status === "accepted" && "Diterima (Antrean)"}
                        {order.status === "preparing" && "Pembuatan Barista"}
                        {order.status === "ready" && "Siap Diambil"}
                        {order.status === "completed" && "Selesai"}
                        {order.status === "cancelled" && "Dibatalkan"}
                      </span>
                    </div>
                  </div>

                  {/* items */}
                  <div className="space-y-2">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="text-xs text-stone-750">
                        <div className="flex justify-between font-medium">
                          <span>
                            <strong className="text-stone-900">{item.quantity}x</strong> {item.name}
                          </span>
                          <span className="font-mono text-stone-500">
                            Rp {(item.price * item.quantity).toLocaleString("id-ID")}
                          </span>
                        </div>
                        {item.notes && (
                          <p className="text-[10px] text-amber-600 font-mono italic mt-0.5 bg-amber-50/50 px-1.5 py-0.5 rounded border border-amber-100/30">
                            Note: {item.notes}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>

                   {/* Total price including PB1 Tax / Voucher discounts */}
                   <div className="border-t border-stone-105 pt-3 space-y-1 bg-stone-50/50 p-2.5 rounded-xl">
                     {order.discountApplied ? (
                       <>
                         <div className="flex items-center justify-between text-[11px] text-stone-505">
                           <span>Subtotal</span>
                           <span className="font-mono">Rp {order.totalPrice.toLocaleString("id-ID")}</span>
                         </div>
                         <div className="flex items-center justify-between text-[11px] text-emerald-700 font-medium">
                           <span>Potongan Voucher</span>
                           <span className="font-mono">-Rp {order.discountApplied.toLocaleString("id-ID")}</span>
                         </div>
                         <div className="flex items-center justify-between text-[11px] text-stone-505">
                           <span>Pajak PB1 (10%)</span>
                           <span className="font-mono">
                             Rp {Math.max(0, (order.totalPrice - order.discountApplied) * 0.1).toLocaleString("id-ID")}
                           </span>
                         </div>
                         <div className="flex items-center justify-between text-xs font-bold text-stone-900 border-t border-stone-200/50 pt-1 mt-1">
                           <span>Total Bayar</span>
                           <span className="font-mono text-amber-700">
                             Rp {Math.max(0, (order.totalPrice - order.discountApplied) * 1.1).toLocaleString("id-ID")}
                           </span>
                         </div>
                       </>
                     ) : (
                       <div className="flex items-center justify-between text-xs font-semibold text-stone-900">
                         <span>Tagihan (Tax PB1 10% incl.)</span>
                         <span className="font-mono font-bold text-amber-700 text-sm">
                           Rp {(order.totalPrice * 1.1).toLocaleString("id-ID")}
                         </span>
                       </div>
                     )}
                   </div>
                </div>

                {/* State transitioning Actions buttons */}
                <div className="pt-2 flex flex-col gap-2">
                  {order.status !== "completed" && order.status !== "cancelled" ? (
                    <div className="flex items-center gap-2">
                      {/* Primary transition CTA button */}
                      <button
                        id={`btn-transition-${order.id}`}
                        onClick={() => transitionOrderStatus(order.id, order.status)}
                        className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm ${
                          order.status === "pending"
                            ? "bg-amber-600 hover:bg-amber-700 text-white shadow-amber-600/10"
                            : order.status === "accepted"
                            ? "bg-indigo-600 hover:bg-indigo-700 text-white"
                            : order.status === "preparing"
                            ? "bg-sky-600 hover:bg-sky-700 text-white"
                            : "bg-emerald-600 hover:bg-emerald-700 text-white animate-bounce"
                        }`}
                      >
                        <Check className="w-4 h-4" />
                        {order.status === "pending" && "Terima Pesanan"}
                        {order.status === "accepted" && "Mulai Sedang Dibuat"}
                        {order.status === "preparing" && "Tandai Siap Diambil"}
                        {order.status === "ready" && "Selesaikan Order"}
                      </button>

                      {/* Cancel Order by administrator */}
                      <button
                        onClick={() => handleCancelOrderByCashier(order.id)}
                        className="p-2 border border-rose-200 hover:bg-rose-50 text-rose-600 rounded-xl transition cursor-pointer"
                        title="Batalkan Pesanan dari Dapur"
                      >
                        <Ban className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="bg-stone-50 p-2.5 rounded-xl border border-stone-200/55 flex justify-center text-xs font-semibold text-stone-500">
                      {order.status === "completed" ? "Selesai ✓" : "Pesanan Dibatalkan ✕"}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white border border-stone-105 p-16 text-center rounded-2xl shadow-sm">
          <Clock className="w-10 h-10 text-stone-300 mx-auto mb-3" />
          <p className="text-sm font-semibold text-stone-600">Tidak ada antrean pesanan</p>
          <p className="text-xs text-stone-400 mt-1">Belum ada pesanan masuk untuk filter ini hari ini.</p>
        </div>
      )}
    </div>
  );
}
