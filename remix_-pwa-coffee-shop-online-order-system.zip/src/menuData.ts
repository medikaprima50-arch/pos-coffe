import { MenuItem } from "./types";

export const INITIAL_MENU: MenuItem[] = [
  {
    id: "kopi-susu-aren",
    name: "Kopi Susu Gula Aren",
    description: "Espresso double shot dengan susu segar dingin dan sirup gula aren murni khas Nusantara.",
    price: 22000,
    category: "Signature Coffee",
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "cappuccino",
    name: "Cappuccino Klasik",
    description: "Espresso premium dipadukan dangan susu berbusa tebal (steamed milk) dan taburan bubuk cokelat manis.",
    price: 26000,
    category: "Classic Coffee",
    image: "https://images.unsplash.com/photo-1534778101976-62847782c213?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "espresso-double",
    name: "Espresso Double Shot",
    description: "Ekstraksi murni biji kopi Arabica specialty pilihan untuk penambah energi instan.",
    price: 18000,
    category: "Classic Coffee",
    image: "https://images.unsplash.com/photo-1510972527409-cef190317417?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "caramel-macchiato",
    name: "Caramel Macchiato",
    description: "Perpaduan lembut espresso, susu segar vanilla, dan sirup karamel gurih di atasnya.",
    price: 29000,
    category: "Signature Coffee",
    image: "https://images.unsplash.com/photo-1485808191679-5f86510681a2?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "matcha-latte",
    name: "Matcha Latte Premium",
    description: "Bubuk green tea Uji Kyoto autentik yang diseduh dengan susu segar hangat atau dingin.",
    price: 25000,
    category: "Non-Coffee",
    image: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "chocolate-signature",
    name: "Signature Dark Chocolate",
    description: "Kakao hitam pekat premium yang kaya dengan krim susu segar, manis gurih seimbang.",
    price: 24000,
    category: "Non-Coffee",
    image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "almond-croissant",
    name: "Butter Almond Croissant",
    description: "Pastry khas Perancis yang renyah di luar, lembut di dalam dengan taburan kacang almond melimpah.",
    price: 28000,
    category: "Snack & Food",
    image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "cinnamon-roll",
    name: "Classic Cinnamon Roll",
    description: "Roti gulung rasa kayumanis wangi disiram glaze gula vanilla lumer di mulut.",
    price: 22000,
    category: "Snack & Food",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "waffle-icecream",
    name: "Belgian Waffle Wild Berry",
    description: "Waffle hangat renyah disajikan dengan es krim vanilla lembut dan sirup buah berry liar segar.",
    price: 32000,
    category: "Snack & Food",
    image: "https://images.unsplash.com/photo-1562376502-6f769499c886?w=500&auto=format&fit=crop&q=60",
    available: true
  },
  {
    id: "chocolate-brownie",
    name: "Fudge Brownie Sundae",
    description: "Brownis panggang cokelat pekat chewy disajikan dengan es krim vanilla dan sirup cokelat.",
    price: 27000,
    category: "Snack & Food",
    image: "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?w=500&auto=format&fit=crop&q=60",
    available: true
  }
];
