import React, { useState, useEffect } from "react";
import RoleToggle from "./components/RoleToggle";
import CustomerView from "./components/CustomerView";
import CashierView from "./components/CashierView";
import { X, CheckCircle2, AlertCircle, Coffee, Info, BellRing } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ToastNotification {
  id: string;
  message: string;
  type: "success" | "info" | "warning";
  timestamp: Date;
}

export default function App() {
  const [role, setRole] = useState<"customer" | "cashier">("customer");
  const [notifications, setNotifications] = useState<ToastNotification[]>([]);

  // Push a new real-time toast to the queue. Keep only 1 visible at a time.
  const addNotification = (message: string, type: "success" | "info" | "warning" = "info") => {
    const newNotif: ToastNotification = {
      id: Math.random().toString(36).substring(2, 9),
      message,
      type,
      timestamp: new Date(),
    };
    
    setNotifications([newNotif]);
  };

  // Auto clean the notification after 5 seconds of appearing
  useEffect(() => {
    if (notifications.length === 0) return;

    const timer = setTimeout(() => {
      setNotifications([]);
    }, 5000);

    return () => clearTimeout(timer);
  }, [notifications]);

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#fcfbf9] text-stone-800 transition duration-300">
      {/* Top Banner & Mode Selectors */}
      <RoleToggle currentRole={role} onRoleChange={(r) => setRole(r)} />

      {/* Main Core Router */}
      <main className="flex-1 w-full pb-20">
        {role === "customer" ? (
          <CustomerView onNewNotification={addNotification} />
        ) : (
          <CashierView onNewNotification={addNotification} />
        )}
      </main>

      {/* Footer Branding Credit */}
      <footer className="border-t border-stone-200/50 bg-white py-6 mt-12 text-center text-xs text-stone-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 Kopi Senja Coffee & Eatery. Hak Cipta Dilindungi.</p>
          <div className="flex items-center gap-1.5 font-display text-stone-500 font-medium bg-stone-100 px-3 py-1.5 rounded-full border border-stone-250/20">
            <Coffee className="w-3.5 h-3.5 text-amber-500" />
            Digital PWA Self-Order System v1.4
          </div>
        </div>
      </footer>

      {/* Real-time Single Toast Alert Overlay with slider transition */}
      <div className="fixed top-20 right-4 z-[100] w-full max-w-[280px] sm:max-w-xs pointer-events-none p-1 overflow-hidden">
        <AnimatePresence mode="popLayout">
          {notifications.map((notif) => (
            <motion.div
              key={notif.id}
              initial={{ opacity: 0, x: 150 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 150 }}
              transition={{ type: "spring", stiffness: 320, damping: 26 }}
              className={`p-2.5 rounded-xl border shadow-md flex items-start gap-2.5 text-[11px] font-medium select-none bg-white/95 backdrop-blur-md pointer-events-auto w-full ${
                notif.type === "success"
                  ? "border-emerald-200 text-emerald-900"
                  : notif.type === "warning"
                  ? "border-rose-200 text-rose-900"
                  : "border-indigo-200 text-indigo-900"
              }`}
            >
              {/* Dynamic Status Icons */}
              <div className="mt-0.5 shrink-0">
                {notif.type === "success" && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                {notif.type === "warning" && <AlertCircle className="w-3.5 h-3.5 text-rose-600" />}
                {notif.type === "info" && <BellRing className="w-3.5 h-3.5 text-indigo-650" />}
              </div>

              {/* Message Body */}
              <div className="flex-1 min-w-0">
                <p className="leading-tight break-words">{notif.message}</p>
                <span className="text-[9px] text-stone-400 block mt-0.5 font-mono">
                  {notif.timestamp.toLocaleTimeString("id", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                </span>
              </div>

              {/* Expel Toggle */}
              <button
                onClick={() => removeNotification(notif.id)}
                className="text-stone-400 hover:text-stone-605 p-0.5 rounded transition cursor-pointer shrink-0"
              >
                <X className="w-3 h-3" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
