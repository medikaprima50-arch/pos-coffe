export interface MenuItem {
  id: string;
  name: string;
  category: "Classic Coffee" | "Signature Coffee" | "Non-Coffee" | "Snack & Food";
  price: number;
  description: string;
  image: string;
  available: boolean;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
}

export type OrderStatus = "pending" | "accepted" | "preparing" | "ready" | "completed" | "cancelled";

export interface Order {
  id: string;
  customerId?: string; // Links this order to customer's loyalty account
  appliedVoucherId?: string; // Links applied voucher
  discountApplied?: number; // Total deduction from subtotal
  customerName: string;
  tableNumber: string;
  items: OrderItem[];
  totalPrice: number; // Subtotal before tax and order discounts
  status: OrderStatus;
  createdAt: any; // Firestore Timestamp or Date ISO string
  updatedAt: any;
}

export interface LoyaltyAccount {
  customerId: string;
  customerName: string;
  points: number;
  earnedPointsTotal: number;
  redeemedPointsTotal: number;
  createdAt: any;
  updatedAt: any;
}

export interface LoyaltyHistory {
  id: string;
  customerId: string;
  type: "earn" | "redeem" | "refund";
  points: number; // positive for earn / refund, negative for redeem
  description: string;
  createdAt: any;
}

export interface Voucher {
  id: string;
  customerId: string;
  type: "discount_10k" | "discount_25k" | "free_coffee" | "free_snack";
  title: string;
  code: string; // e.g., SENJA-10K-A8B9C
  pointsCost: number;
  status: "available" | "used";
  createdAt: any;
  usedAt?: any;
}

