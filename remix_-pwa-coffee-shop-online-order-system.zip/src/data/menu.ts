import { MenuItem } from "../types";

export const INITIAL_MENU: MenuItem[] = [
  {
    id: "c1",
    name: "Espresso Double Shot",
    category: "Classic Coffee",
    price: 22000,
    description: "Ekstrak kopi pekat murni dari 100% biji kopi Arabika pilihan.",
    image: "https://images.unsplash.com/photo-1510707513156-46c2977d78a3?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "c2",
    name: "Classic Cafe Latte",
    category: "Classic Coffee",
    price: 28000,
    description: "Double shot espresso dengan susu segar pilihan dan foam lembut di atasnya.",
    image: "https://images.unsplash.com/photo-1570968915860-54d5c301fc9f?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "c3",
    name: "Cappuccino Senja",
    category: "Classic Coffee",
    price: 28000,
    description: "Espresso dengan rasio seimbang antara susu dan foam kelapa yang legit.",
    image: "https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "s1",
    name: "Es Kopi Susu Aren Melati",
    category: "Signature Coffee",
    price: 30000,
    description: "Espresso dicampur gula aren organik murni dan infusa aroma melati segar khas Senja.",
    image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "s2",
    name: "Caramel Macchiato Heaven",
    category: "Signature Coffee",
    price: 33000,
    description: "Susu vanila kental, espresso float dengan saus gula caramel homemade.",
    image: "https://images.unsplash.com/photo-1485808191679-5f86510681a2?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "s3",
    name: "Avocado Affogato Deluxe",
    category: "Signature Coffee",
    price: 35000,
    description: "Jus alpukat premium segar disajikan dengan es krim vanila dan double espresso shot.",
    image: "https://images.unsplash.com/photo-1594911774802-8822a707cff3?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "n1",
    name: "Matcha Latte Kyoto",
    category: "Non-Coffee",
    price: 28000,
    description: "Matcha murni impor Kyoto dipadukan dengan kelembutan susu vanilla.",
    image: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "n2",
    name: "Premium Belgian Chocolate",
    category: "Non-Coffee",
    price: 29000,
    description: "Cokelat Belgia murni berkualitas tinggi disajikan hangat atau dingin dengan whipped cream.",
    image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "n3",
    name: "Lychee Yakult Sparkler",
    category: "Non-Coffee",
    price: 26000,
    description: "Soda menyegarkan dicampur dengan Yakult segar dan potongan buah leci asli.",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "f1",
    name: "Butter Croissant Crispy",
    category: "Snack & Food",
    price: 24000,
    description: "Croissant panggang renyah beraroma mentega Prancis premium manis gurih.",
    image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "f2",
    name: "Truffle Fries with Aioli",
    category: "Snack & Food",
    price: 28000,
    description: "Kentang goreng renyah dibaluri minyak truffle murni dan disajikan dengan saus cocolan aioli bawang putih.",
    image: "https://images.unsplash.com/photo-1576107232684-1279f390859f?auto=format&fit=crop&q=80&w=400",
    available: true
  },
  {
    id: "f3",
    name: "Mie Goreng Senja Spesial",
    category: "Snack & Food",
    price: 32000,
    description: "Mie goreng kaya rempah khas Senja dengan topping sosis premium, telur ceplok dan kerupuk udang.",
    image: "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&q=80&w=400",
    available: true
  }
];
