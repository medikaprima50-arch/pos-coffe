export interface RewardItem {
  id: string;
  title: string;
  description: string;
  pointsCost: number;
  type: "discount_10k" | "discount_25k" | "free_coffee" | "free_snack";
  value: number; // For discount type, this represents IDR deduction amount
}

export const REWARD_ITEMS: RewardItem[] = [
  {
    id: "discount_10k",
    title: "Voucher Diskon Rp 10.000",
    description: "Nikmati potongan harga Rp 10.000 untuk transaksi apa saja tanpa minimal pembelian.",
    pointsCost: 100,
    type: "discount_10k",
    value: 10000,
  },
  {
    id: "discount_25k",
    title: "Voucher Diskon Rp 25.000",
    description: "Nikmati potongan harga spesial Rp 25.000 untuk pesanan Anda.",
    pointsCost: 220,
    type: "discount_25k",
    value: 25000,
  },
  {
    id: "free_coffee",
    title: "1 Kopi Klasik Gratis",
    description: "Tukarkan dengan 1 minuman kopi klasik gratis (espresso, americano, latte, atau cappuccino).",
    pointsCost: 150,
    type: "free_coffee",
    value: 0,
  },
  {
    id: "free_snack",
    title: "1 Snack / Camilan Gratis",
    description: "Tukarkan dengan jenis snack atau menu makanan ringan apa saja di Kopi Senja.",
    pointsCost: 130,
    type: "free_snack",
    value: 0,
  },
];
